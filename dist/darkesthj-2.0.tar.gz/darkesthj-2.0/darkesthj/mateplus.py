from math import sqrt

def hipotenusa(cateto1,cateto2):
    h = round(sqrt((cateto1**2)+(cateto2**2)),2)
    return h



